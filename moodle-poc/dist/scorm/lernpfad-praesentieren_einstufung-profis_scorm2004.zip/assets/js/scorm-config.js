window.LP_SCORM_CONFIG = {"module": "einstufung-profis", "launch": "einstufung-profis.html", "files": ["einstufung-profis.html", "regeln.html", "videos.html"]};
