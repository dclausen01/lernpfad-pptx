window.LP_SCORM_CONFIG = {"module": "e6", "launch": "e6-praesentieren.html", "files": ["e6-praesentieren.html", "regeln.html", "videos.html"]};
