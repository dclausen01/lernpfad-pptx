window.LP_SCORM_CONFIG = {"module": "e4", "launch": "e4-design.html", "files": ["e4-design.html", "regeln.html", "videos.html"]};
