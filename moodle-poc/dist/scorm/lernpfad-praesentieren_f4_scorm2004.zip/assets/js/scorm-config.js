window.LP_SCORM_CONFIG = {"module": "f4", "launch": "f4-tabellen-diagramme.html", "files": ["f4-tabellen-diagramme.html", "regeln.html", "videos.html"]};
