window.LP_SCORM_CONFIG = {"module": "f5", "launch": "f5-smartart.html", "files": ["f5-smartart.html", "regeln.html", "videos.html"]};
