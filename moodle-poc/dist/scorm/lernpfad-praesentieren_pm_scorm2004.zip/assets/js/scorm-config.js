window.LP_SCORM_CONFIG = {"module": "pm", "launch": "pm-meilenstein.html", "files": ["pm-meilenstein.html", "regeln.html", "videos.html"]};
