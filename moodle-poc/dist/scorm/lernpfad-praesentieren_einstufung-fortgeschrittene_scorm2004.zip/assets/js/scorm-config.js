window.LP_SCORM_CONFIG = {"module": "einstufung-fortgeschrittene", "launch": "einstufung-fortgeschrittene.html", "files": ["einstufung-fortgeschrittene.html", "regeln.html", "videos.html"]};
