window.LP_SCORM_CONFIG = {"module": "f1", "launch": "f1-uebergaenge.html", "files": ["f1-uebergaenge.html", "regeln.html", "videos.html"]};
