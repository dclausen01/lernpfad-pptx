window.LP_SCORM_CONFIG = {"module": "p5", "launch": "p5-barrierefrei-teamarbeit.html", "files": ["p5-barrierefrei-teamarbeit.html", "regeln.html", "videos.html"]};
