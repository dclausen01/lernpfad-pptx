window.LP_SCORM_CONFIG = {"module": "fm", "launch": "fm-meilenstein.html", "files": ["fm-meilenstein.html", "regeln.html", "videos.html"]};
