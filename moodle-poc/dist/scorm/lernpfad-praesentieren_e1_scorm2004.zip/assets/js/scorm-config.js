window.LP_SCORM_CONFIG = {"module": "e1", "launch": "e1-oberflaeche.html", "files": ["e1-oberflaeche.html", "regeln.html", "videos.html"]};
