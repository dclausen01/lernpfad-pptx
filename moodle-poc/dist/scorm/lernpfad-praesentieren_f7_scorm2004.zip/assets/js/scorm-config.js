window.LP_SCORM_CONFIG = {"module": "f7", "launch": "f7-vortragen.html", "files": ["f7-vortragen.html", "regeln.html", "videos.html"]};
