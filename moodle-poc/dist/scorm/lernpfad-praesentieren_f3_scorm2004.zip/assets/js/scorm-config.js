window.LP_SCORM_CONFIG = {"module": "f3", "launch": "f3-ausrichten.html", "files": ["f3-ausrichten.html", "regeln.html", "videos.html"]};
