window.LP_SCORM_CONFIG = {"module": "e5", "launch": "e5-bilder-formen.html", "files": ["e5-bilder-formen.html", "regeln.html", "videos.html"]};
