window.LP_SCORM_CONFIG = {"module": "p1", "launch": "p1-folienmaster.html", "files": ["p1-folienmaster.html", "regeln.html", "videos.html"]};
