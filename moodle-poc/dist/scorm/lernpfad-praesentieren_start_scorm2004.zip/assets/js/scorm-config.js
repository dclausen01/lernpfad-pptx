window.LP_SCORM_CONFIG = {"module": "start", "launch": "start.html", "files": ["start.html", "regeln.html", "videos.html"]};
