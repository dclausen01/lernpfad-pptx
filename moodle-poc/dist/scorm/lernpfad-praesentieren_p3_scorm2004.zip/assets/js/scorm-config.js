window.LP_SCORM_CONFIG = {"module": "p3", "launch": "p3-interaktiv.html", "files": ["p3-interaktiv.html", "regeln.html", "videos.html"]};
