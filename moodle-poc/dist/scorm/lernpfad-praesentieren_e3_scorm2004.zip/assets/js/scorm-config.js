window.LP_SCORM_CONFIG = {"module": "e3", "launch": "e3-text.html", "files": ["e3-text.html", "regeln.html", "videos.html"]};
