window.LP_SCORM_CONFIG = {"module": "e2", "launch": "e2-folien.html", "files": ["e2-folien.html", "regeln.html", "videos.html"]};
