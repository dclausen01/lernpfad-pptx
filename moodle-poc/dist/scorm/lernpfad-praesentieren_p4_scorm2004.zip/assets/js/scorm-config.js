window.LP_SCORM_CONFIG = {"module": "p4", "launch": "p4-audio-video.html", "files": ["p4-audio-video.html", "regeln.html", "videos.html"]};
