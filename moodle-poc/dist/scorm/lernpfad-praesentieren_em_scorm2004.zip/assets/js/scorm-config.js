window.LP_SCORM_CONFIG = {"module": "em", "launch": "em-meilenstein.html", "files": ["em-meilenstein.html", "regeln.html", "videos.html"]};
