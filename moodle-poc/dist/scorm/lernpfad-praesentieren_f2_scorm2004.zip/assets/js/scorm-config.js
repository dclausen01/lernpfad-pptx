window.LP_SCORM_CONFIG = {"module": "f2", "launch": "f2-animationen.html", "files": ["f2-animationen.html", "regeln.html", "videos.html"]};
