window.LP_SCORM_CONFIG = {"module": "p2", "launch": "p2-morphen.html", "files": ["p2-morphen.html", "regeln.html", "videos.html"]};
