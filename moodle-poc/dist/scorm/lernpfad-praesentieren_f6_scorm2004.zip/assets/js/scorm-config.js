window.LP_SCORM_CONFIG = {"module": "f6", "launch": "f6-fusszeile-links.html", "files": ["f6-fusszeile-links.html", "regeln.html", "videos.html"]};
